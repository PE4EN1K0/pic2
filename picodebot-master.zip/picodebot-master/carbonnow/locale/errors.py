class Error(Exception):
    pass


class HostDownError(Error):
    pass
