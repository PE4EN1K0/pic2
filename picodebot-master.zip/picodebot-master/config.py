class Config:
    bot_token = "TOKEN"
