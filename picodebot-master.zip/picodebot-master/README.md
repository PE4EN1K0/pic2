<a href="https://t.me/serenecorp"><img alt="Issues" src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"></a>

**📒 Source code of the** [@PicodeBot](https://t.me/picodebot)

**🧸 Developer:** [@hoosnick](https://t.me/hoosnick)
<hr>

## Run
1. `$ git clone https://github.com/hoosnick/picodebot.git`
2. `$ pip install -r requirements.txt`
3. <b>Paste your token in the</b> [config.py](https://github.com/hoosnick/picodebot/blob/b39d813e4ba9b724a77ece7be809dad26c53a56b/config.py) <b>file</b>
4. `python3 main.py`
<hr>

## Sample files
* [data.db](https://github.com/hoosnick/picodebot/blob/b39d813e4ba9b724a77ece7be809dad26c53a56b/config.py) - sample database
* [sample.service](https://github.com/hoosnick/picodebot/blob/b39d813e4ba9b724a77ece7be809dad26c53a56b/config.py) - sample service for deploying in vps
